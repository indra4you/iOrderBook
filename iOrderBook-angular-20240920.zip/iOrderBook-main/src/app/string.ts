export function toTrim(
    value: string,
): string {
    return value.trim();
};